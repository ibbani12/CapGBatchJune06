//composite demo code, LoginPage is a composite (collection) class consisting of Button, Window and 
//menubar components. All components are derived from components base class. LoginPage implements the 
// add() - method to add  a component to collection, draw()- to invoke component specific  draw method
// and draw the component

/*
Component � Component declares the interface for objects 
Leaf � Leaf defines behavior for primitive objects in the composition. - Eg Button, Window, Menubar
Composite � Composite stores child components and implements child related operations in the component interface. - Eg LoginPage
Client � Client manipulates the objects in the composition through the component interface.
*/

#include <iostream>
//#include <string>
//#include <cstring>
#include <vector>


#define NUM_BUTTONS  3
#define NUM_WINDOWS	2
#define NUM_MENUBARS  2
using namespace std;



//Interface class
class Component
{
	public:
	    Component(){}
		~Component(){}
		
		// to be implemented by specific component
		virtual void draw() = 0; 
		
		//to add the components
		virtual int add(){}
	
};

class Button:public Component
{
	static int id;
	public:
	
		Button()
		{
			id++;
			cid = id;
		}
		~Button(){}
		void draw()
		{
			cout << "Button id:" << cid << "draw()" << endl;
		}
	private:
	    int cid; //component id
	
};



class Window:public Component
{
	static int id;
	public:
		Window()
		{
			id++;
			cid = id;
		}
		~Window(){}
		void draw()
		{
			cout << "Window id:" << cid << "draw()" << endl;
		}
	private:
	    int cid; //component id
	
};


class Menubar:public Component //why is derived from Component and not from subclass
{
	static int id;
	public:
		Menubar()
		{
			id++;
			cid = id;
		}
		void draw()
		{
			cout << "Menubar id:" << cid << "draw()" << endl;
		}
	private:
	    int cid; //component id
	
};

//composite class
class LoginPage:public Component
{
    static int count;
	public:
		
		~LoginPage()
		{
			vObj.erase(vObj.begin(), vObj.end());
			cout << "elements in vector after erase:" << vObj.size() <<endl;
		}
		void draw()
		{
			
			
			//draw contained objects
			for (it = vObj.begin(); it != vObj.end(); it++)
			{
				//invoke type specific draw method
				Component* cobj = *it;
				cobj->draw();
			}
		}
		void add(Component *cobj)
		{
			vObj.push_back(cobj);			
			cout << "Added component :" << count << endl;
			count++;
		}
		int dispCount()
		{
			cout << "Tot. components are :" << count <<endl;
		}
		private:
		 	//composite vector of components i.e windows, menubars etc 
		 	// composite showing has a relationsship
			vector<Component *> vObj;
			vector<Component *>::iterator it;
		

	
};


//initialize static members
int Button::id = 0;
int Window::id = 0;
int Menubar::id = 0;
int LoginPage::count = 0;

//adapter class implements interface
int main()
{
	//create client
	LoginPage *lobj = new LoginPage;
	Button *bobj[3] = {0};
	int i =0;
	
	for (i = 0; i < NUM_BUTTONS; i++)
	{
		bobj[i] = new Button;
		lobj->add(bobj[i]);
	 }
	 
	for ( i = 0; i < NUM_WINDOWS; i++)
	{
		Window *obj = new Window;
		lobj->add(obj);
	 }
	for (i = 0; i < NUM_MENUBARS; i++)
	{
		Menubar *obj = new Menubar;
		lobj->add(obj);
	}
	cout << "Test" << endl;
	lobj->dispCount();
	
	//draw and display the components
	cout << " to call draw of loginpage" << endl;
	 
	
    lobj->draw();
	delete lobj;
}



/* output

input
Added component :0                                                                                                                                                                   
Added component :1                                                                                                                                                                   
Added component :2                                                                                                                                                                   
Added component :3                                                                                                                                                                   
Added component :4                                                                                                                                                                   
Added component :5                                                                                                                                                                   
Added component :6                                                                                                                                                                   
Test                                                                                                                                                                                 
Tot. components are :7                                                                                                                                                               
 to call draw of loginpage                                                                                                                                                           
Button id:1draw()                                                                                                                                                                    
Button id:2draw()                                                                                                                                                                    
Button id:3draw()                                                                                                                                                                    
Window id:1draw()                                                                                                                                                                    
Window id:2draw()                                                                                                                                                                    
Menubar id:1draw()                                                                                                                                                                   
Menubar id:2draw()                                                                                                                                                                   
elements in vector:0    
*/

