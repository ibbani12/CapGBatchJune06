Assignment 1::

/*This file contains code snippet 
* And you are supposed to make a change in the following code
* so that when one object state changes all other objects will reflect
* this change
*/

#include<iostream>
#include<list>
using namespace std;


//forward declaration::
class Observer;

//create Subject
class Subject {

private:
    list<Observer*> observers;
    int state;
public:
    Subject() :state(0){} 
    
    int getState() {
        return state;
    }

    void setState(int state) {
        this->state = state;
    }

    void attach(Observer* observer) {
        observers.push_back(observer);
    }
};

// Observer
class Observer {
protected:
    Subject* subject=NULL;
public:
    virtual void update() = 0;
};

class BinaryObserver :public Observer {

public:
    BinaryObserver(Subject* sub) {
        this->subject = sub;
        subject->attach(this);
    }

    //Override
    void update() {
        cout << "\nBinary String: " << ios::binary << subject->getState();
    }
};

class OctalObserver :public Observer {

public:
    OctalObserver(Subject* subject) {
        this->subject = subject;
        this->subject->attach(this);
    }

    //Override
    void update() {
        cout << "\nOctal String: " << ios::oct << subject->getState();
    }
};

class HexaObserver :public Observer {

public:
    HexaObserver(Subject* subject) {
        this->subject = subject;
        this->subject->attach(this);
    }

    //Override
    void update() {
        cout << "\nHex String: " << ios::hex << subject->getState();
    }
};

int main()
{
    Subject* subject = new Subject();

    Observer* ob1 = new HexaObserver(subject);
    Observer* ob2 = new OctalObserver(subject);
    Observer*  ob3 = new BinaryObserver(subject);
   

    cout << "\nFirst state change: 15";
    subject->setState(15);
    //updating explicitly all objects to new state::
    ob1->update();    
    ob2->update();
    ob3->update();

    cout << "\n\nSecond state change: 10";
    subject->setState(10);
    //repeat updating when again state changes::
    ob1->update();
    ob2->update();
    ob3->update();

    delete ob1;
    delete ob2;
    delete ob3;
    cout << "\n\n";
    return 0;
}

-------------------------------------------------------------------------------------------------------------------
Assignment 2::


/*This file contains a program using polymorphism to create objects in the client code
Now, say that my system wants to introduce new player "WAV"
As my client code is exposing the implementation of derived classes
I want to convert this heirarchy by adding classes/method so that,
client can use new player without exposing the creation logic */

#include<iostream>
using namespace std;

//Macros for displaying valid strings
#define MP3_STRING "MP3"
#define AVI_STRING "AVI"
#define WAV_STRING "WAV"

//Macros for menu provided to user
#define MP3 1
#define AVI 2
#define WAV 3



class Player {
public:
	virtual void Play() = 0;
};

class VideoPlayer :public Player {
public:
	void Play() = 0;
};

class AudioPlayer :public Player {
public:
	void Play() = 0;
};

class MP3Player :public AudioPlayer {
public:
	void Play() {
		cout << "\nPlaying MP3....\n";
	}
};

class AVIPlayer :public VideoPlayer {
public:
	void Play() {
		cout << "\nPlaying AVI .........\n";
	}
};

//client
int main() {
	int choice;
	cout <<"\n1:MP3\
            \n2:AVI"\
		"\nEnter which player you want to start::";
	cin >> choice;

	Player* obj=NULL;
	switch (choice)
	{
	case MP3:
		obj = new MP3Player();
		obj->Play();
		break;
	case AVI:
		obj = new AVIPlayer();
		obj->Play();
		break;
	case 0:
		exit(0);
	}
	delete obj;

	return 0;
}