//demo code for observer pattern
//online compiler

#include <iostream>
#include <string>
#include <cstring>
#include <fstream>
#include <vector>
#include <memory>

using namespace std;

//IObserver
class IObserver
{
	public:
	    virtual	void update(){};
		
};

//subject interface class
class ISubject
{
	public:
	    virtual void myregister(IObserver *obj){}
	    virtual void unregister(IObserver *obj){}
		virtual void notify(){}
	
};


//Observer
class Smartphone:public IObserver
{
	public:
		Smartphone(ISubject *iobj)
		{
			isub = iobj;
			isub->myregister(this);
			cout << "Smartphone constructor" << endl;
		}
		~Smartphone()
		{
			isub->unregister(this);
			cout << "Smartphone destr" << endl;
		}
		void update()
		{
			cout << "smartphone : recvd temp change notification" << endl;
		}
	private:
		ISubject *isub;
};

//Observer2
class Lcddisplay:public IObserver
{
	public:
		Lcddisplay(ISubject *iobj)
		{
			isub = iobj;
			isub->myregister(this);
			cout << "Lcddisplay constructor" << endl;
		}
		~Lcddisplay()
		{
			isub->unregister(this);
			cout << "Lcddisplay destr" << endl;
		}
		void update()
		{
			cout << "Lcddisplay : recvd temp change notification" << endl;
		}
	private:
		ISubject *isub;
};



class TempSensor:public ISubject
{
	public:
		TempSensor()
		{
			cout << "TempSensor constructor" << endl;
		}
		~TempSensor()
		{
			oblist.erase(oblist.begin(), oblist.end());
			cout << "TempSensor destructor" << endl;
		}
		void myregister(IObserver *obj);
		void unregister(IObserver *obj);
		void notify();
		vector<IObserver *>oblist; //vector of observer list
};

void TempSensor::myregister(IObserver *obj)
{
	oblist.push_back(obj);
	cout << "Register obj "		 << oblist.size() << endl;
}

void TempSensor::unregister(IObserver *obj)
{
    //TBD to delete obj from vector
	cout << "Unregistered obj" << oblist.size() << endl;
}
//notified all registered subscribers
void TempSensor::notify()
{
	for (auto it = oblist.begin(); it!= oblist.end(); it++)
	{
		IObserver *obj = *it;
		obj->update();
	}
}



int main()
{
	TempSensor *tobj = new TempSensor;
	
	//initialize the smartphone object and register for notifications
	Smartphone *sobj = new Smartphone(tobj); //pass the temp subject object so that on notification, value can be fetched

	cout << "to notify all observers" << endl;
	tobj->notify();
	
	delete sobj;
	delete tobj;
}

/* output
TempSensor constructor                                                                                                                                                               
Register obj 1                                                                                                                                                                       
Smartphone constructor                                                                                                                                                               
to notify all observers                                                                                                                                                              
smartphone : recvd temp change notification                                                                                                                                          
Unregistered obj1                                                                                                                                                                    
Smartphone destr                                                                                                                                                                     
TempSensor destructor 
*/
