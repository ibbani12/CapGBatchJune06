/* It creates 1 thread
startroutine1 is the starting point of thread.
It is demonstrating the following points:

1. What would happen if sleep(1) is removed from main 
2. How would you ensure that newly created thread will complete its execution.

Note:In Unix environment if main thread exits then automatically others threads 
also exit
*/ 

#include <pthread.h>
#include<stdio.h>
#include<stdlib.h>

void main_function(const char *s)
{
    pid_t       pid;
    pthread_t   tid;

    pid = getpid(); /* Returns Process id */
    tid = pthread_self(); /* Returns thread id */
    printf("%s pid %lu tid %lu (0x%lx)\n", s, (unsigned long)pid,
      (unsigned long)tid, (unsigned long)tid);
}

void *startroutine1(void *arg)
{
    main_function("new thread:");
    return((void *)0);
}

int main(void)
{
    int retval;

	pthread_t threadid;
    retval = pthread_create(&threadid, NULL, startroutine1, NULL);/* Creates POSIX threads*/
    if (retval != 0)
        perror("can't create thread");
    main_function("main thread:");
    sleep(1);
    exit(0);
}

