#include <EMSG.h>


bool is_email_valid(const std::string& email){
     
   const std::regex pattern
      ("(\\w+)(\\.|_)?(\\w*)@(\\w+)(\\.(\\w+))+");

   return regex_match(email, pattern);
}

int main(int argc, char*argv[])
{       
        if(argc!=2)
        {
        cout<<"Invalid cmd arguments:"<<endl;
        }
        
        string email = argv[1];
       cout << email << " : " << (is_email_valid(email) ?
      "valid" : "invalid") << endl;
       
	MSG m;
	key_t key;
	int msgid;

	// to gen unique key
	key = ftok("mydata", 100);

	msgid = msgget(key, PERMS | IPC_CREAT);
	if(msgid<0)
	{
		perror("msgget() error");
		exit(EXIT_FAILURE);
	}

	m.msg_type = 1;
	cout<<"\nEnter a msg to be sent\n";
	fgets(m.email, MAXBUF, stdin);

	msgsnd(msgid, &m, sizeof(m),0);

	cout<<"\nTransfered email : "<<m.email<<endl;

	return (EXIT_SUCCESS);
}
