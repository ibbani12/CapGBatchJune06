#include <iostream>
#include <sys/msg.h>
#include <EMSG.h>

int emailrcv()
{
	MSG m;

	key_t key;
	int msgid;

	// to gen unique key
	key = ftok("mydata", 100);

	msgid = msgget(key, PERMS | IPC_CREAT);
	if(msgid<0)
	{
		perror("msgget() error");
		exit(EXIT_FAILURE);
	}

	while(msgrcv(msgid, &m, sizeof(m),1,0)){

		cout<<"\nReceived emails : "<<m.email<<endl;
	}
	msgctl(msgid, IPC_RMID, NULL);
       // End;

	return (EXIT_SUCCESS);
}
