#include <iostream>
#include <sys/msg.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <regex>
#define PERMS 0666
#define MAXBUF 1024

using namespace std;

struct msg_buf{
    long msg_type;
    char email[1024];
};

typedef struct msg_buf MSG;


bool is_email_valid();